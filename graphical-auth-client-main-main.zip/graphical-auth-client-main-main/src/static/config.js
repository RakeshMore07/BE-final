export const api = {
  // url: "https://graphical-auth.onrender.com",
  url: "http://localhost:3002",
};
