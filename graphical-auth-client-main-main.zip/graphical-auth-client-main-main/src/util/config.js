export const Page = {
  HOME_PAGE: "Landing",
  SIGNUP_PAGE: "signup",
  ABOUT: "about",
  CONTACT: "contact",
  LOGIN_PAGE: "loginpage",
  PRE_PAGE: "home",
};

export const header = { headers: { "Access-Control-Allow-Origin": "*" } };
